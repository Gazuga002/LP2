﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btntestepalindromo_Click(object sender, EventArgs e)
        {
             
        
            String frase = richTextBox1.Text.ToUpper().Replace(" ", "");
            String fraseInvertida = new string(frase.Reverse().ToArray());


            if (frase == fraseInvertida)
            {
                MessageBox.Show(fraseInvertida + "\n É palíndromo!");
            }
            else
            {
                MessageBox.Show(fraseInvertida + "\n Não é palíndromo!");
            }
        }
    }
}
