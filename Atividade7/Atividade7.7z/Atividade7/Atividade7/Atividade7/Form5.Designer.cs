﻿namespace Atividade7
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnome = new System.Windows.Forms.TextBox();
            this.btnsalariobruto = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtproducao = new System.Windows.Forms.TextBox();
            this.txtsalario = new System.Windows.Forms.TextBox();
            this.txtgratificacao = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(274, 67);
            this.txtnome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(197, 22);
            this.txtnome.TabIndex = 0;
            // 
            // btnsalariobruto
            // 
            this.btnsalariobruto.Location = new System.Drawing.Point(573, 150);
            this.btnsalariobruto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnsalariobruto.Name = "btnsalariobruto";
            this.btnsalariobruto.Size = new System.Drawing.Size(174, 65);
            this.btnsalariobruto.TabIndex = 1;
            this.btnsalariobruto.Text = "Calcular Salario Bruto";
            this.btnsalariobruto.UseVisualStyleBackColor = true;
            this.btnsalariobruto.Click += new System.EventHandler(this.btnsalariobruto_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(63, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Matricula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Produção";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Salário";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Gratificação";
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(274, 118);
            this.txtmatricula.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(197, 22);
            this.txtmatricula.TabIndex = 7;
            // 
            // txtproducao
            // 
            this.txtproducao.Location = new System.Drawing.Point(274, 174);
            this.txtproducao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtproducao.Name = "txtproducao";
            this.txtproducao.Size = new System.Drawing.Size(197, 22);
            this.txtproducao.TabIndex = 8;
            // 
            // txtsalario
            // 
            this.txtsalario.Location = new System.Drawing.Point(274, 222);
            this.txtsalario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtsalario.Name = "txtsalario";
            this.txtsalario.Size = new System.Drawing.Size(197, 22);
            this.txtsalario.TabIndex = 9;
            // 
            // txtgratificacao
            // 
            this.txtgratificacao.Location = new System.Drawing.Point(274, 272);
            this.txtgratificacao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtgratificacao.Name = "txtgratificacao";
            this.txtgratificacao.Size = new System.Drawing.Size(197, 22);
            this.txtgratificacao.TabIndex = 10;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(831, 402);
            this.Controls.Add(this.txtgratificacao);
            this.Controls.Add(this.txtsalario);
            this.Controls.Add(this.txtproducao);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnsalariobruto);
            this.Controls.Add(this.txtnome);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.Button btnsalariobruto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtproducao;
        private System.Windows.Forms.TextBox txtsalario;
        private System.Windows.Forms.TextBox txtgratificacao;
    }
}