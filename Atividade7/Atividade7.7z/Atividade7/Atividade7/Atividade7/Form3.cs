﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

     

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int numero;
            Double resultado = 0;

            //validacao
            if (!int.TryParse(txtnumeroN.Text, out numero) || (numero == 0))
            {
                MessageBox.Show("Digite um NÚMERO que seja MAIOR do que 0!");
                txtnumeroN.Focus();
                return;
            }

            //calculo
            for (int i = 1; i <= numero; i++)
            {
                resultado += 1.0 / i;
            }
            MessageBox.Show("O número H é: " + resultado.ToString("F2"));
        }
    }
}
    

