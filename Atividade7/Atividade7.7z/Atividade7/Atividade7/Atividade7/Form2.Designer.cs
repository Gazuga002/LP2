﻿namespace Atividade7
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ATE300 = new System.Windows.Forms.RichTextBox();
            this.ESPBRANCO = new System.Windows.Forms.Button();
            this.CONTADORR = new System.Windows.Forms.Button();
            this.LETRASIGUAIS = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ATE300
            // 
            this.ATE300.Location = new System.Drawing.Point(190, 58);
            this.ATE300.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ATE300.Name = "ATE300";
            this.ATE300.Size = new System.Drawing.Size(230, 96);
            this.ATE300.TabIndex = 0;
            this.ATE300.Text = "";
            this.ATE300.TextChanged += new System.EventHandler(this.RichText_TextChanged);
            // 
            // ESPBRANCO
            // 
            this.ESPBRANCO.Location = new System.Drawing.Point(122, 241);
            this.ESPBRANCO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ESPBRANCO.Name = "ESPBRANCO";
            this.ESPBRANCO.Size = new System.Drawing.Size(109, 55);
            this.ESPBRANCO.TabIndex = 1;
            this.ESPBRANCO.Text = "Num. Espaços em branco";
            this.ESPBRANCO.UseVisualStyleBackColor = true;
            this.ESPBRANCO.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // CONTADORR
            // 
            this.CONTADORR.Location = new System.Drawing.Point(284, 241);
            this.CONTADORR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CONTADORR.Name = "CONTADORR";
            this.CONTADORR.Size = new System.Drawing.Size(91, 55);
            this.CONTADORR.TabIndex = 2;
            this.CONTADORR.Text = "Contador de \"R\"";
            this.CONTADORR.UseVisualStyleBackColor = true;
            this.CONTADORR.Click += new System.EventHandler(this.btnVezesR_Click);
            // 
            // LETRASIGUAIS
            // 
            this.LETRASIGUAIS.Location = new System.Drawing.Point(413, 241);
            this.LETRASIGUAIS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LETRASIGUAIS.Name = "LETRASIGUAIS";
            this.LETRASIGUAIS.Size = new System.Drawing.Size(92, 55);
            this.LETRASIGUAIS.TabIndex = 3;
            this.LETRASIGUAIS.Text = "Letras iguais (AA)";
            this.LETRASIGUAIS.UseVisualStyleBackColor = true;
            this.LETRASIGUAIS.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.LETRASIGUAIS);
            this.Controls.Add(this.CONTADORR);
            this.Controls.Add(this.ESPBRANCO);
            this.Controls.Add(this.ATE300);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox ATE300;
        private System.Windows.Forms.Button ESPBRANCO;
        private System.Windows.Forms.Button CONTADORR;
        private System.Windows.Forms.Button LETRASIGUAIS;
    }
}