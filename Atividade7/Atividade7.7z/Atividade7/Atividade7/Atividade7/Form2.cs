﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace Atividade7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void RichText_TextChanged(object sender, EventArgs e)
        {
            ATE300.MaxLength = 300;
            
            
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int numeroEspaco = 0;
            int tamanhoFrase = ATE300.Text.Length;

            if (ATE300.Text == "")
                MessageBox.Show("Digite uma frase na caixa de texto!");

            for (int i = 0; i < tamanhoFrase; i++)
            {
                if (Char.IsWhiteSpace(ATE300.Text[i]))
                {
                    numeroEspaco++;
                }
            }
            MessageBox.Show("O numero de espaços em branco na frase é: " + numeroEspaco);
        }

        private void btnVezesR_Click(object sender, EventArgs e)
        {
            int qtdeR = 0;
            foreach (char c in ATE300.Text.ToUpper())
            {
                if (c == 'R')
                    qtdeR++;
            }
            MessageBox.Show("O numero de letras 'R' na frase é: " + qtdeR);
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int pares = 0;
            int i = 0;

            while (i < ATE300.Text.Length - 1)
            {
                if (ATE300.Text[i] == ATE300.Text[i + 1])
                {
                    pares++;
                }
                i++;
            }
            MessageBox.Show("O numero de vezes que há letras é: " + pares);
        }
    }
}
