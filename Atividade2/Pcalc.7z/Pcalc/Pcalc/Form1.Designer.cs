﻿namespace Pcalc
{
    partial class FormCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelNumero1 = new System.Windows.Forms.Label();
            this.LabelNumero2 = new System.Windows.Forms.Label();
            this.LabelResultado = new System.Windows.Forms.Label();
            this.textnum1 = new System.Windows.Forms.TextBox();
            this.textnum2 = new System.Windows.Forms.TextBox();
            this.textresultado = new System.Windows.Forms.TextBox();
            this.blimpar = new System.Windows.Forms.Button();
            this.bsair = new System.Windows.Forms.Button();
            this.bmais = new System.Windows.Forms.Button();
            this.bmenos = new System.Windows.Forms.Button();
            this.bmult = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LabelNumero1
            // 
            this.LabelNumero1.AutoSize = true;
            this.LabelNumero1.Location = new System.Drawing.Point(97, 108);
            this.LabelNumero1.Name = "LabelNumero1";
            this.LabelNumero1.Size = new System.Drawing.Size(78, 20);
            this.LabelNumero1.TabIndex = 0;
            this.LabelNumero1.Text = "Numero 1";
            // 
            // LabelNumero2
            // 
            this.LabelNumero2.AutoSize = true;
            this.LabelNumero2.Location = new System.Drawing.Point(97, 160);
            this.LabelNumero2.Name = "LabelNumero2";
            this.LabelNumero2.Size = new System.Drawing.Size(78, 20);
            this.LabelNumero2.TabIndex = 1;
            this.LabelNumero2.Text = "Numero 2";
            // 
            // LabelResultado
            // 
            this.LabelResultado.AutoSize = true;
            this.LabelResultado.Location = new System.Drawing.Point(97, 211);
            this.LabelResultado.Name = "LabelResultado";
            this.LabelResultado.Size = new System.Drawing.Size(82, 20);
            this.LabelResultado.TabIndex = 2;
            this.LabelResultado.Text = "Resultado";
            // 
            // textnum1
            // 
            this.textnum1.Location = new System.Drawing.Point(272, 108);
            this.textnum1.Name = "textnum1";
            this.textnum1.Size = new System.Drawing.Size(98, 26);
            this.textnum1.TabIndex = 3;
            this.textnum1.Validated += new System.EventHandler(this.textBox1_Validated);
            // 
            // textnum2
            // 
            this.textnum2.Location = new System.Drawing.Point(272, 160);
            this.textnum2.Name = "textnum2";
            this.textnum2.Size = new System.Drawing.Size(98, 26);
            this.textnum2.TabIndex = 4;
            this.textnum2.Validated += new System.EventHandler(this.textBox2_Validated);
            // 
            // textresultado
            // 
            this.textresultado.Location = new System.Drawing.Point(272, 205);
            this.textresultado.Name = "textresultado";
            this.textresultado.Size = new System.Drawing.Size(98, 26);
            this.textresultado.TabIndex = 5;
            // 
            // blimpar
            // 
            this.blimpar.Location = new System.Drawing.Point(386, 108);
            this.blimpar.Name = "blimpar";
            this.blimpar.Size = new System.Drawing.Size(89, 48);
            this.blimpar.TabIndex = 6;
            this.blimpar.Text = "LIMPAR";
            this.blimpar.UseVisualStyleBackColor = true;
            this.blimpar.Click += new System.EventHandler(this.blimpar_Click);
            // 
            // bsair
            // 
            this.bsair.Location = new System.Drawing.Point(386, 173);
            this.bsair.Name = "bsair";
            this.bsair.Size = new System.Drawing.Size(89, 48);
            this.bsair.TabIndex = 7;
            this.bsair.Text = "SAIR";
            this.bsair.UseVisualStyleBackColor = true;
            this.bsair.Click += new System.EventHandler(this.bsair_Click);
            // 
            // bmais
            // 
            this.bmais.Location = new System.Drawing.Point(101, 265);
            this.bmais.Name = "bmais";
            this.bmais.Size = new System.Drawing.Size(89, 48);
            this.bmais.TabIndex = 8;
            this.bmais.Text = "+";
            this.bmais.UseVisualStyleBackColor = true;
            this.bmais.Click += new System.EventHandler(this.bmais_Click);
            // 
            // bmenos
            // 
            this.bmenos.Location = new System.Drawing.Point(196, 265);
            this.bmenos.Name = "bmenos";
            this.bmenos.Size = new System.Drawing.Size(89, 48);
            this.bmenos.TabIndex = 9;
            this.bmenos.Text = "-";
            this.bmenos.UseVisualStyleBackColor = true;
            this.bmenos.Click += new System.EventHandler(this.bmenos_Click);
            // 
            // bmult
            // 
            this.bmult.Location = new System.Drawing.Point(291, 265);
            this.bmult.Name = "bmult";
            this.bmult.Size = new System.Drawing.Size(89, 48);
            this.bmult.TabIndex = 10;
            this.bmult.Text = "*";
            this.bmult.UseVisualStyleBackColor = true;
            this.bmult.Click += new System.EventHandler(this.bmult_Click);
            // 
            // bdiv
            // 
            this.bdiv.Location = new System.Drawing.Point(386, 265);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(89, 48);
            this.bdiv.TabIndex = 11;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = true;
            this.bdiv.Click += new System.EventHandler(this.bdiv_Click);
            // 
            // FormCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 571);
            this.Controls.Add(this.bdiv);
            this.Controls.Add(this.bmult);
            this.Controls.Add(this.bmenos);
            this.Controls.Add(this.bmais);
            this.Controls.Add(this.bsair);
            this.Controls.Add(this.blimpar);
            this.Controls.Add(this.textresultado);
            this.Controls.Add(this.textnum2);
            this.Controls.Add(this.textnum1);
            this.Controls.Add(this.LabelResultado);
            this.Controls.Add(this.LabelNumero2);
            this.Controls.Add(this.LabelNumero1);
            this.Name = "FormCalculadora";
            this.Text = "SUPER CALCULADORA DA NASA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelNumero1;
        private System.Windows.Forms.Label LabelNumero2;
        private System.Windows.Forms.Label LabelResultado;
        private System.Windows.Forms.TextBox textnum1;
        private System.Windows.Forms.TextBox textnum2;
        private System.Windows.Forms.TextBox textresultado;
        private System.Windows.Forms.Button blimpar;
        private System.Windows.Forms.Button bsair;
        private System.Windows.Forms.Button bmais;
        private System.Windows.Forms.Button bmenos;
        private System.Windows.Forms.Button bmult;
        private System.Windows.Forms.Button bdiv;
    }
}

