﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class FormCalculadora : Form
    {
        double num1, num2, resultado;

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textnum2.Text, out num2) || (num2 == 0))
            { MessageBox.Show("Digite um número diferente de 0!");
                textnum2.Focus();
            }
        }

        private void bsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void blimpar_Click(object sender, EventArgs e)
        {
            textnum1.Clear();
            textnum2.Clear();
            textresultado.Clear();
        }

        private void bmais_Click(object sender, EventArgs e)
        {
            resultado=(num1+ num2);
            textresultado.Text = resultado.ToString();
        }

        private void bmenos_Click(object sender, EventArgs e)
        {
            resultado=(num1- num2);
            textresultado.Text = resultado.ToString();
        }

        private void bmult_Click(object sender, EventArgs e)
        {
            resultado = (num1 * num2);
            textresultado.Text = resultado.ToString();
        }

        private void bdiv_Click(object sender, EventArgs e)
        {
            resultado = (num1/num2);
            textresultado.Text = resultado.ToString();
        }

        public FormCalculadora()
        {
         InitializeComponent();
        }
        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textnum1.Text, out num1))
            {
                MessageBox.Show("Por favor digite um número!");
                    textnum1.Focus();
            }
        }


    }
}
