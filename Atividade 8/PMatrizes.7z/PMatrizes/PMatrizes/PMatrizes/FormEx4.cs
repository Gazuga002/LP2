﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class FormEx4 : Form
    {
        public FormEx4()
        {
            InitializeComponent();
        }

        private void btnNomes_Click(object sender, EventArgs e)
        {
            string[] vetorNome = new string[10];
            int[] vetorTamanho = new int[10];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome para saber seu tamanho (sem espaços)", "Entrada de dados");

                if (auxiliar.Replace(" ", "").Length == 0)
                {
                    MessageBox.Show("Digite nome válido!");
                    i--;
                }
                else
                {
                    vetorNome[i] = auxiliar;
                    vetorTamanho[i] = auxiliar.Replace(" ", "").Length;
                }

                listboxNomes.Items.Add($"Nome {vetorNome[i]}, tamanho {vetorTamanho[i]}");



            }
        }
    }
}
