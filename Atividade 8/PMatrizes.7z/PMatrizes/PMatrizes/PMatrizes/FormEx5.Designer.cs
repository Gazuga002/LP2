﻿namespace PMatrizes
{
    partial class FormEx5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificarNotas = new System.Windows.Forms.Button();
            this.listboxNotas = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVerificarNotas
            // 
            this.btnVerificarNotas.Location = new System.Drawing.Point(148, 124);
            this.btnVerificarNotas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVerificarNotas.Name = "btnVerificarNotas";
            this.btnVerificarNotas.Size = new System.Drawing.Size(124, 37);
            this.btnVerificarNotas.TabIndex = 0;
            this.btnVerificarNotas.Text = "Verificar Notas";
            this.btnVerificarNotas.UseVisualStyleBackColor = true;
            this.btnVerificarNotas.Click += new System.EventHandler(this.btnVerificarNotas_Click);
            // 
            // listboxNotas
            // 
            this.listboxNotas.FormattingEnabled = true;
            this.listboxNotas.ItemHeight = 16;
            this.listboxNotas.Location = new System.Drawing.Point(358, 37);
            this.listboxNotas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listboxNotas.Name = "listboxNotas";
            this.listboxNotas.Size = new System.Drawing.Size(293, 260);
            this.listboxNotas.TabIndex = 1;
            // 
            // FormEx5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.listboxNotas);
            this.Controls.Add(this.btnVerificarNotas);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormEx5";
            this.Text = "FormEx5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerificarNotas;
        private System.Windows.Forms.ListBox listboxNotas;
    }
}