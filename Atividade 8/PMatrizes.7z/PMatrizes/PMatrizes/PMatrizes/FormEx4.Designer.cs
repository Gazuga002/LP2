﻿namespace PMatrizes
{
    partial class FormEx4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNomes = new System.Windows.Forms.Button();
            this.listboxNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnNomes
            // 
            this.btnNomes.Location = new System.Drawing.Point(77, 120);
            this.btnNomes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNomes.Name = "btnNomes";
            this.btnNomes.Size = new System.Drawing.Size(123, 62);
            this.btnNomes.TabIndex = 0;
            this.btnNomes.Text = "Receber nomes";
            this.btnNomes.UseVisualStyleBackColor = true;
            this.btnNomes.Click += new System.EventHandler(this.btnNomes_Click);
            // 
            // listboxNomes
            // 
            this.listboxNomes.FormattingEnabled = true;
            this.listboxNomes.ItemHeight = 16;
            this.listboxNomes.Location = new System.Drawing.Point(267, 23);
            this.listboxNomes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listboxNomes.Name = "listboxNomes";
            this.listboxNomes.Size = new System.Drawing.Size(364, 276);
            this.listboxNomes.TabIndex = 1;
            // 
            // FormEx4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.listboxNomes);
            this.Controls.Add(this.btnNomes);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormEx4";
            this.Text = "FormEx4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNomes;
        private System.Windows.Forms.ListBox listboxNomes;
    }
}