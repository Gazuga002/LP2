﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnex1 = new System.Windows.Forms.Button();
            this.btnex2 = new System.Windows.Forms.Button();
            this.btnex3 = new System.Windows.Forms.Button();
            this.btnex4 = new System.Windows.Forms.Button();
            this.btnEx5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnex1
            // 
            this.btnex1.Location = new System.Drawing.Point(96, 62);
            this.btnex1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnex1.Name = "btnex1";
            this.btnex1.Size = new System.Drawing.Size(100, 56);
            this.btnex1.TabIndex = 0;
            this.btnex1.Text = "Vetor Entrada de 20 números";
            this.btnex1.UseVisualStyleBackColor = true;
            this.btnex1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnex2
            // 
            this.btnex2.Location = new System.Drawing.Point(259, 62);
            this.btnex2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnex2.Name = "btnex2";
            this.btnex2.Size = new System.Drawing.Size(112, 56);
            this.btnex2.TabIndex = 1;
            this.btnex2.Text = "Lista Alunos ArrayList";
            this.btnex2.UseVisualStyleBackColor = true;
            this.btnex2.Click += new System.EventHandler(this.btnex2_Click);
            // 
            // btnex3
            // 
            this.btnex3.Location = new System.Drawing.Point(96, 130);
            this.btnex3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnex3.Name = "btnex3";
            this.btnex3.Size = new System.Drawing.Size(100, 45);
            this.btnex3.TabIndex = 2;
            this.btnex3.Text = "Guardar 3 notas alunos ";
            this.btnex3.UseVisualStyleBackColor = true;
            this.btnex3.Click += new System.EventHandler(this.btnex3_Click);
            // 
            // btnex4
            // 
            this.btnex4.Location = new System.Drawing.Point(259, 130);
            this.btnex4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnex4.Name = "btnex4";
            this.btnex4.Size = new System.Drawing.Size(102, 45);
            this.btnex4.TabIndex = 3;
            this.btnex4.Text = "Nomes de 10 Pessoas";
            this.btnex4.UseVisualStyleBackColor = true;
            this.btnex4.Click += new System.EventHandler(this.btnex4_Click);
            // 
            // btnEx5
            // 
            this.btnEx5.Location = new System.Drawing.Point(96, 194);
            this.btnEx5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEx5.Name = "btnEx5";
            this.btnEx5.Size = new System.Drawing.Size(106, 44);
            this.btnEx5.TabIndex = 4;
            this.btnEx5.Text = "Verificar Notas";
            this.btnEx5.UseVisualStyleBackColor = true;
            this.btnEx5.Click += new System.EventHandler(this.btnEx5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "EX 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(214, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "EX 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "EX 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(214, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "EX 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "EX 5";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(255, 194);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 44);
            this.button1.TabIndex = 10;
            this.button1.Text = "SAIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnEx5);
            this.Controls.Add(this.btnex4);
            this.Controls.Add(this.btnex3);
            this.Controls.Add(this.btnex2);
            this.Controls.Add(this.btnex1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "PMatrizes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnex1;
        private System.Windows.Forms.Button btnex2;
        private System.Windows.Forms.Button btnex3;
        private System.Windows.Forms.Button btnex4;
        private System.Windows.Forms.Button btnEx5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}

