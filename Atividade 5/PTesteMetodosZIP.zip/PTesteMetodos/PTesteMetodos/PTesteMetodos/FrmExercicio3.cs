﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox2.Text.Replace(textBox1.Text, "");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //inutil deletar depois
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string auxiliar = textBox1.Text;
            char[] arr = auxiliar.ToCharArray();
            Array.Reverse(arr);

            auxiliar = "";
            foreach (char cara in arr) 
            {
                    auxiliar += cara;
            }
            MessageBox.Show(auxiliar);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
