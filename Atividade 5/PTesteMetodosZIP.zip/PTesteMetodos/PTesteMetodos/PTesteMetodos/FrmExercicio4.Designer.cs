﻿namespace PTesteMetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNum = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnBlank = new System.Windows.Forms.Button();
            this.btnAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNum
            // 
            this.btnNum.Location = new System.Drawing.Point(46, 216);
            this.btnNum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(171, 54);
            this.btnNum.TabIndex = 0;
            this.btnNum.Text = "Contar caracteres numéricos.";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(180, 39);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(337, 150);
            this.rchtxtFrase.TabIndex = 1;
            this.rchtxtFrase.Text = "";
            // 
            // btnBlank
            // 
            this.btnBlank.Location = new System.Drawing.Point(259, 216);
            this.btnBlank.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBlank.Name = "btnBlank";
            this.btnBlank.Size = new System.Drawing.Size(183, 54);
            this.btnBlank.TabIndex = 2;
            this.btnBlank.Text = "Posição do primeiro Caractere em Branco";
            this.btnBlank.UseVisualStyleBackColor = true;
            this.btnBlank.Click += new System.EventHandler(this.btnBlank_Click);
            // 
            // btnAlfa
            // 
            this.btnAlfa.Location = new System.Drawing.Point(485, 216);
            this.btnAlfa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAlfa.Name = "btnAlfa";
            this.btnAlfa.Size = new System.Drawing.Size(160, 54);
            this.btnAlfa.TabIndex = 3;
            this.btnAlfa.Text = "Contar caracteres alfabéticos.";
            this.btnAlfa.UseVisualStyleBackColor = true;
            this.btnAlfa.Click += new System.EventHandler(this.btnAlfa_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.btnAlfa);
            this.Controls.Add(this.btnBlank);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnNum);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnBlank;
        private System.Windows.Forms.Button btnAlfa;
    }
}