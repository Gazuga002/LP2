﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contnumero = 0;
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contnumero++;
                   
                }
                contador++;
            
            }
            MessageBox.Show("O número de caracteres numéricos é:" + contnumero);
        }

        private void btnBlank_Click(object sender, EventArgs e)
        {
            int i = 0;
            int posicao = 0;

            for (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            MessageBox.Show("O primeiro espaço em branco fica na posição: " + posicao);
        }

        private void btnAlfa_Click(object sender, EventArgs e)
        {
            int letra = 0;

            foreach (char caractere in rchtxtFrase.Text)
            {
                if (char.IsLetter(caractere))
                {
                    letra += 1;
                }
            }
            MessageBox.Show("O numero de caracteres é: " + letra);
        }
    }
}
