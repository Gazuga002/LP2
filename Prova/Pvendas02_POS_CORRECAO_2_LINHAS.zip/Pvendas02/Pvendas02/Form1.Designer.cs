﻿namespace Pvendas02
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnverificar = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.listboxtotal = new System.Windows.Forms.ListBox();
            this.btnfechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(176, 79);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(153, 91);
            this.btnverificar.TabIndex = 0;
            this.btnverificar.Text = "Verificar";
            this.btnverificar.UseVisualStyleBackColor = true;
            this.btnverificar.Click += new System.EventHandler(this.btnverificar_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(176, 198);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(153, 82);
            this.btnlimpar.TabIndex = 1;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // listboxtotal
            // 
            this.listboxtotal.FormattingEnabled = true;
            this.listboxtotal.ItemHeight = 20;
            this.listboxtotal.Location = new System.Drawing.Point(405, 79);
            this.listboxtotal.Name = "listboxtotal";
            this.listboxtotal.Size = new System.Drawing.Size(337, 304);
            this.listboxtotal.TabIndex = 2;
            // 
            // btnfechar
            // 
            this.btnfechar.Location = new System.Drawing.Point(176, 301);
            this.btnfechar.Name = "btnfechar";
            this.btnfechar.Size = new System.Drawing.Size(153, 82);
            this.btnfechar.TabIndex = 3;
            this.btnfechar.Text = "Fechar";
            this.btnfechar.UseVisualStyleBackColor = true;
            this.btnfechar.Click += new System.EventHandler(this.btnfechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnfechar);
            this.Controls.Add(this.listboxtotal);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnverificar);
            this.Name = "Form1";
            this.Text = "Vendas";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.ListBox listboxtotal;
        private System.Windows.Forms.Button btnfechar;
    }
}

