﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void btnlimpar_Click(object sender, EventArgs e)
        {
           listboxtotal.Items.Clear();
        }

        private void btnfechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            double[,] valores = new double [2, 4];
            string auxiliar ="";
            double totalmes=0, totalgeral=0;
            int i, j;
            double davez;

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox("Digite o valor do mês " + (i + 1) + " - " + "Semana " + (j + 1) + ":");

                    if (!double.TryParse(auxiliar, out valores[i, j]) || (valores[i, j] < 0) || auxiliar.Length == 0)
                    {
                        MessageBox.Show("Valor inálido para o mês digite um número positivo!");
                        j--;
                    }
                    else
                    {
                        davez = Convert.ToDouble(auxiliar);
                        listboxtotal.Items.Add("Total do mês : " + (i + 1) + " - " + "Semana " + (j + 1) + ":"+ davez);
                        totalmes = totalmes + davez;

                        
                    }
                    
                }
                listboxtotal.Items.Add(">> Total Mês : " + totalmes);
                listboxtotal.Items.Add("----------------------");
                totalgeral= totalgeral+ totalmes;
            }
            
            listboxtotal.Items.Add(">> Total Geral : " + totalgeral);

        }
    }

}
