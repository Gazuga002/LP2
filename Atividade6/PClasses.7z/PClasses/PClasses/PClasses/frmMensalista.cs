﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class formmensalista : Form
    {
        public formmensalista()
        {
            InitializeComponent();
        }

        private void btnInstMensal_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtnome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtmatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtdataentrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtsalario.Text);


            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n"+
                "Matricula="+objMensalista.Matricula+"\n"+
                "Tempo Trabalho="+objMensalista.TempoTrabalho()+"\n"+
                "Salario Final="+objMensalista.SalarioBruto().ToString("N2"));

        }

        private void btnIntMensalPara_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(
                Convert.ToInt32(txtmatricula.Text),
                txtnome.Text,
                Convert.ToDateTime(txtdataentrada.Text),
                Convert.ToDouble(txtsalario.Text));

            MessageBox.Show("Nome=" + ObjMensalista.NomeEmpregado + "\n" +
               "Matricula=" + ObjMensalista.Matricula + "\n" +
               "Tempo Trabalho=" + ObjMensalista.TempoTrabalho() + "\n" +
               "Salario Final=" + ObjMensalista.SalarioBruto().ToString("N2"));

            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show($"Empresa: {Mensalista.Empresa}");
        }
    }
}
