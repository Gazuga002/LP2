﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstMensal_Click(object sender, EventArgs e)
        {
            Horista objHorista= new Horista();

            objHorista.NomeEmpregado = txtnome.Text;
            objHorista.Matricula = Convert.ToInt32(txtmatricula.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtdataentrada.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtsalario.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtfalta.Text);

            MessageBox.Show("Nome=" + objHorista.NomeEmpregado + "\n" +
               "Matricula=" + objHorista.Matricula + "\n" +
               "Tempo Trabalho=" + objHorista.TempoTrabalho() + "\n" +
               "Salario =" + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
