﻿namespace PClasses
{
    partial class formmensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstMensal = new System.Windows.Forms.Button();
            this.btnIntMensalPara = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtsalario = new System.Windows.Forms.TextBox();
            this.txtdataentrada = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnInstMensal
            // 
            this.btnInstMensal.Location = new System.Drawing.Point(117, 294);
            this.btnInstMensal.Name = "btnInstMensal";
            this.btnInstMensal.Size = new System.Drawing.Size(205, 82);
            this.btnInstMensal.TabIndex = 0;
            this.btnInstMensal.Text = "Instanciar Mensalista";
            this.btnInstMensal.UseVisualStyleBackColor = true;
            this.btnInstMensal.Click += new System.EventHandler(this.btnInstMensal_Click);
            // 
            // btnIntMensalPara
            // 
            this.btnIntMensalPara.Location = new System.Drawing.Point(458, 294);
            this.btnIntMensalPara.Name = "btnIntMensalPara";
            this.btnIntMensalPara.Size = new System.Drawing.Size(205, 82);
            this.btnIntMensalPara.TabIndex = 1;
            this.btnIntMensalPara.Text = "Instanciar Mensalista parâmetros";
            this.btnIntMensalPara.UseVisualStyleBackColor = true;
            this.btnIntMensalPara.Click += new System.EventHandler(this.btnIntMensalPara_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(145, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Matricula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(145, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Salario Mensal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(145, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Data entrada Empresa";
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(428, 61);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(204, 26);
            this.txtmatricula.TabIndex = 6;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(428, 114);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(204, 26);
            this.txtnome.TabIndex = 7;
            // 
            // txtsalario
            // 
            this.txtsalario.Location = new System.Drawing.Point(428, 166);
            this.txtsalario.Name = "txtsalario";
            this.txtsalario.Size = new System.Drawing.Size(204, 26);
            this.txtsalario.TabIndex = 8;
            // 
            // txtdataentrada
            // 
            this.txtdataentrada.Location = new System.Drawing.Point(428, 211);
            this.txtdataentrada.Name = "txtdataentrada";
            this.txtdataentrada.Size = new System.Drawing.Size(204, 26);
            this.txtdataentrada.TabIndex = 9;
            // 
            // formmensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtdataentrada);
            this.Controls.Add(this.txtsalario);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIntMensalPara);
            this.Controls.Add(this.btnInstMensal);
            this.Name = "formmensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstMensal;
        private System.Windows.Forms.Button btnIntMensalPara;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtsalario;
        private System.Windows.Forms.TextBox txtdataentrada;
    }
}