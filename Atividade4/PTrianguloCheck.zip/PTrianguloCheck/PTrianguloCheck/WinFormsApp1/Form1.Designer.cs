﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl1 = new Label();
            lbl2 = new Label();
            lbl3 = new Label();
            txtbm1 = new TextBox();
            txtbm2 = new TextBox();
            txtbm3 = new TextBox();
            btnlimpar = new Button();
            btnsair = new Button();
            btnverificar = new Button();
            SuspendLayout();
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Location = new Point(82, 47);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(109, 20);
            lbl1.TabIndex = 0;
            lbl1.Text = "Medida Lado 1";
            // 
            // lbl2
            // 
            lbl2.AutoSize = true;
            lbl2.Location = new Point(82, 113);
            lbl2.Name = "lbl2";
            lbl2.RightToLeft = RightToLeft.Yes;
            lbl2.Size = new Size(109, 20);
            lbl2.TabIndex = 1;
            lbl2.Text = "Medida Lado 2";
            // 
            // lbl3
            // 
            lbl3.AutoSize = true;
            lbl3.Location = new Point(82, 181);
            lbl3.Name = "lbl3";
            lbl3.Size = new Size(109, 20);
            lbl3.TabIndex = 2;
            lbl3.Text = "Medida Lado 3";
            // 
            // txtbm1
            // 
            txtbm1.Location = new Point(304, 47);
            txtbm1.Name = "txtbm1";
            txtbm1.Size = new Size(125, 27);
            txtbm1.TabIndex = 3;
            txtbm1.Validated += txtbm1_Validated;
            // 
            // txtbm2
            // 
            txtbm2.Location = new Point(304, 110);
            txtbm2.Name = "txtbm2";
            txtbm2.Size = new Size(125, 27);
            txtbm2.TabIndex = 4;
            txtbm2.Validated += txtbm2_Validated;
            // 
            // txtbm3
            // 
            txtbm3.Location = new Point(304, 174);
            txtbm3.Name = "txtbm3";
            txtbm3.Size = new Size(125, 27);
            txtbm3.TabIndex = 5;
            txtbm3.Validated += txtbm3_Validated;
            // 
            // btnlimpar
            // 
            btnlimpar.Location = new Point(82, 267);
            btnlimpar.Name = "btnlimpar";
            btnlimpar.Size = new Size(147, 46);
            btnlimpar.TabIndex = 8;
            btnlimpar.Text = "Limpar";
            btnlimpar.UseVisualStyleBackColor = true;
            btnlimpar.Click += btnlimpar_Click;
            // 
            // btnsair
            // 
            btnsair.BackColor = SystemColors.ActiveCaption;
            btnsair.Location = new Point(506, 267);
            btnsair.Name = "btnsair";
            btnsair.Size = new Size(147, 46);
            btnsair.TabIndex = 10;
            btnsair.Text = "Sair";
            btnsair.UseVisualStyleBackColor = false;
            btnsair.Click += btnsair_Click;
            // 
            // btnverificar
            // 
            btnverificar.BackColor = SystemColors.MenuHighlight;
            btnverificar.Location = new Point(304, 267);
            btnverificar.Name = "btnverificar";
            btnverificar.Size = new Size(147, 46);
            btnverificar.TabIndex = 9;
            btnverificar.Text = "Verificar";
            btnverificar.UseVisualStyleBackColor = false;
            btnverificar.Click += btnverificar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnverificar);
            Controls.Add(btnsair);
            Controls.Add(btnlimpar);
            Controls.Add(txtbm3);
            Controls.Add(txtbm2);
            Controls.Add(txtbm1);
            Controls.Add(lbl3);
            Controls.Add(lbl2);
            Controls.Add(lbl1);
            Name = "Form1";
            Text = "Check Triângulo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl1;
        private Label lbl2;
        private Label lbl3;
        private TextBox txtbm1;
        private TextBox txtbm2;
        private TextBox txtbm3;
        private Button btnlimpar;
        private Button btnsair;
        private Button btnverificar;
    }
}
