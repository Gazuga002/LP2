using System.Diagnostics.Eventing.Reader;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {

            txtbm1.Clear();
            txtbm2.Clear();
            txtbm3.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }


        Double medida1, medida2, medida3;

        private void btnverificar_Click(object sender, EventArgs e)
        {
           
            if ((medida1 + medida2 <= medida3) ||
                (medida1 + medida3 <= medida2) ||
                medida2 + medida3 <= medida1)
            {
                MessageBox.Show("Valores Inv�lidos! Um dos lados � maior que a soma dos outros dois!");
                txtbm1.Focus();
            }
            else if (medida1 == medida2 && medida2 == medida3)
            {
                MessageBox.Show("Tri�ngulo Equil�tero!");
            }
            else if (medida1 == medida2 || medida2 == medida3 || medida1 == medida3)
            {
                MessageBox.Show("Tri�ngulo Is�celes!");
            }
            else
            {
                MessageBox.Show("Tri�ngulo Escaleno!");
            }
        }

        private void txtbm1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbm1.Text, out medida1)||medida1==0)

            {
                MessageBox.Show("Valores inv�lidos! Digite somente n�meros n�o nulos!");
                txtbm1.Focus();
                
            }
        }
        private void txtbm2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbm2.Text, out medida2) || medida2 == 0)

            {
                MessageBox.Show("Valores inv�lidos! Digite somente n�meros n�o nulos!");
                txtbm2.Focus();

            }
        }
        private void txtbm3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbm3.Text, out medida3) || medida3 == 0)

            {
                MessageBox.Show("Valores inv�lidos! Digite somente n�meros n�o nulos!");
                txtbm3.Focus();

            }
        }
    }
}
