﻿namespace PIMC
{
    partial class IMC
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txtboximc = new System.Windows.Forms.TextBox();
            this.mskbx2 = new System.Windows.Forms.MaskedTextBox();
            this.mskbx1 = new System.Windows.Forms.MaskedTextBox();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.btn_sair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(97, 106);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(86, 20);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Peso Atual";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(97, 171);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(51, 20);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Altura";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(97, 239);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(38, 20);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "IMC";
            // 
            // txtboximc
            // 
            this.txtboximc.Enabled = false;
            this.txtboximc.Location = new System.Drawing.Point(311, 236);
            this.txtboximc.Name = "txtboximc";
            this.txtboximc.Size = new System.Drawing.Size(184, 26);
            this.txtboximc.TabIndex = 3;
            // 
            // mskbx2
            // 
            this.mskbx2.Location = new System.Drawing.Point(311, 171);
            this.mskbx2.Mask = "0.00";
            this.mskbx2.Name = "mskbx2";
            this.mskbx2.Size = new System.Drawing.Size(184, 26);
            this.mskbx2.TabIndex = 2;
            this.mskbx2.Validated += new System.EventHandler(this.mskbx2_Validated);
            // 
            // mskbx1
            // 
            this.mskbx1.Location = new System.Drawing.Point(311, 103);
            this.mskbx1.Mask = "00.00";
            this.mskbx1.Name = "mskbx1";
            this.mskbx1.Size = new System.Drawing.Size(184, 26);
            this.mskbx1.TabIndex = 1;
            this.mskbx1.Validated += new System.EventHandler(this.mskbx1_Validated);
            // 
            // btn_calcular
            // 
            this.btn_calcular.Location = new System.Drawing.Point(101, 317);
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.Size = new System.Drawing.Size(120, 46);
            this.btn_calcular.TabIndex = 6;
            this.btn_calcular.Text = "Calcular";
            this.btn_calcular.UseVisualStyleBackColor = true;
            this.btn_calcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_limpar
            // 
            this.btn_limpar.Location = new System.Drawing.Point(265, 317);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(120, 46);
            this.btn_limpar.TabIndex = 7;
            this.btn_limpar.Text = "Limpar";
            this.btn_limpar.UseVisualStyleBackColor = true;
            this.btn_limpar.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_sair
            // 
            this.btn_sair.Location = new System.Drawing.Point(428, 317);
            this.btn_sair.Name = "btn_sair";
            this.btn_sair.Size = new System.Drawing.Size(111, 46);
            this.btn_sair.TabIndex = 8;
            this.btn_sair.Text = "Sair";
            this.btn_sair.UseVisualStyleBackColor = true;
            this.btn_sair.Click += new System.EventHandler(this.button3_Click);
            // 
            // IMC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1075, 686);
            this.Controls.Add(this.btn_sair);
            this.Controls.Add(this.btn_limpar);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.mskbx1);
            this.Controls.Add(this.mskbx2);
            this.Controls.Add(this.txtboximc);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "IMC";
            this.Text = "IMC Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TextBox txtboximc;
        private System.Windows.Forms.MaskedTextBox mskbx2;
        private System.Windows.Forms.MaskedTextBox mskbx1;
        private System.Windows.Forms.Button btn_calcular;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.Button btn_sair;
    }
}

