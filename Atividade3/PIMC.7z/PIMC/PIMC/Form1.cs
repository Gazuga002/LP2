﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class IMC : Form
    {
        double peso, altura, imc;

        public IMC()
        {
            InitializeComponent();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
           mskbx1.Clear();
           mskbx2.Clear();
           txtboximc.Clear();
        }

        private void mskbx1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbx1.Text, out peso) || (peso == 0))
            {
                if (!double.TryParse(txtboximc.Text, out peso))
                {
                    MessageBox.Show("Digite um peso válido!");
                    mskbx1.Focus();
                }
            }
        }

        private void mskbx2_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(mskbx2.Text, out altura) || (altura==0))
            {
                MessageBox.Show("Digite uma altura válida!");
                mskbx2.Focus(); 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            imc = peso/(altura*altura);
            imc = Math.Round(imc, 1);
            txtboximc.Text= imc.ToString();


            if (imc < 18.5)
            
                MessageBox.Show("Classificação: MAGREZA \n Grau de Obesidade: 0");
                
            
            else if (imc <= 24.9)
                

                MessageBox.Show("Classificação: NORMAL \n Grau de Obesidade: 0");

            
            else if (imc <= 29.9)
                

                MessageBox.Show("Classificação: SOBREPESO \n Grau de Obesidade: I");

            
            else if (imc <= 39.9)
                

                MessageBox.Show("Classificação: OBESIDADE \n Grau de Obesidade: II");

            
            else
            
                MessageBox.Show("Classificação: OBESIDADE GRAVE \n Grau de Obesidade: III");

            
        }

        private void mskbx1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (!double.TryParse(mskbx1.Text, out peso) || (peso == 0))
            {
                if (!double.TryParse(txtboximc.Text, out peso))
                {
                    MessageBox.Show("Digite um peso válido");

                }
            }
        }
    }
}
